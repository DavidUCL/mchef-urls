@theme @theme_boost_union @theme_boost_union_smartmenusettings @theme_boost_union_smartmenusettings_menuitems @theme_boost_union_smartmenusettings_menuitems_presentation
Feature: Configuring the theme_boost_union plugin on the "Smart menus" page, applying different presentation options to the individual smart menu items
  In order to use the features
  As admin
  I need to be able to configure the theme Boost Union plugin

  Background:
    Given the following "custom field categories" exist:
      | name                 | component   | area   | itemid |
      | Course custom fields | core_course | course | 0      |
    And the following "custom fields" exist:
      | name              | category             | type | shortname |
      | Test custom field | Course custom fields | text | testcf    |
    And the following "courses" exist:
      | fullname               | shortname                     | category | customfield_testcf                   |
      | Test course1           | C1                            | 0        | Custom1                              |
      | Test course2           | C2                            | 0        | Custom2                              |
      | Test course word count | C3 has a very long short name | 0        | Custom3 has a very long custom field |
    And the following "users" exist:
      | username |
      | user1    |
    And the following "theme_boost_union > smart menu" exists:
      | title    | Quick links                                      |
      | location | Main navigation, Menu bar, User menu, Bottom bar |

  Scenario Outline: Smartmenus: Menu items: Presentation - Open the smart menu items in different targets
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links       |
      | title    | Available courses |
      | itemtype | Dynamic courses   |
      | category | 0                 |
      | itemmode | Inline            |
      | target   | <setting>         |
    When I log in as "admin"
    Then the "target" attribute of "Test course1" "theme_boost_union > Main menu smart menu item" <should>
    And the "target" attribute of "Test course1" "theme_boost_union > User menu smart menu item" <should>
    And the "target" attribute of "Test course1" "theme_boost_union > Menu bar smart menu item" <should>
    And the "target" attribute of "Test course1" "theme_boost_union > Bottom bar smart menu item" <should>

    Examples:
      | setting     | should                  |
      | New tab     | should contain "_blank" |
      | Same window | should not be set       |

  Scenario: Smartmenus: Menu items: Presentation - Include the custom css class for a smart menu item
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links           |
      | title    | Resources             |
      | itemtype | Static                |
      | url      | http://moodle.org     |
      | cssclass | static-item-resources |
    When I log in as "admin"
    Then the "class" attribute of "Resources" "theme_boost_union > Main menu smart menu item" should contain "static-item-resources"
    And the "class" attribute of "Resources" "theme_boost_union > User menu smart menu item" should contain "static-item-resources"
    And the "class" attribute of "Resources" "theme_boost_union > Menu bar smart menu item" should contain "static-item-resources"
    And the "class" attribute of "Resources" "theme_boost_union > Bottom bar smart menu item" should contain "static-item-resources"

  Scenario Outline: Smartmenus: Menu items: Presentation - Display the different fields as smart menu item title
    Given the following "theme_boost_union > smart menu item" exists:
      | menu                    | Quick links       |
      | title                   | Available courses |
      | itemtype                | Dynamic courses   |
      | category                | 0                 |
      | displayfield            | <firstlinefield>  |
      | displayfieldcustomfield | <firstlinecustom> |
    When I log in as "admin"
    Then I should see smart menu "Quick links" item "<showntitle>" in location "Main, Menu, User, Bottom"
    And I should not see smart menu "Quick links" item "<notshowntitle>" in location "Main, Menu, User, Bottom"

    Examples:
      | firstlinefield                          | firstlinecustom | showntitle             | notshowntitle |
      | Course short name                       |                 | C1                     | Test course   |
      | Course full name                        |                 | Test course word count | C1            |
      | Custom course field                     | testcf          | Custom1                | Test course1  |
      | Course full name (Course short name)    |                 | Test course1 (C1)      | Custom1       |
      | Course short name (Course full name)    |                 | C1 (Test course1)      | Custom1       |
      | Course full name (Custom course field)  | testcf          | Test course1 (Custom1) | C1            |
      | Course short name (Custom course field) | testcf          | C1 (Custom1)           | Test course1  |

  Scenario Outline: Smartmenus: Menu items: Presentation - Display the different fields as smart menu item second line (Show second line cases)
    Given the following "theme_boost_union > smart menu item" exists:
      | menu                          | Quick links        |
      | title                         | Available courses  |
      | itemtype                      | Dynamic courses    |
      | category                      | 0                  |
      # We just set the first line to avoid false positives with the second line values.
      | displayfield                  | <firstlinefield>   |
      | displayfieldcustomfield       | <firstlinecustom>  |
      | displayfieldsecond            | <secondlinefield>  |
      | displayfieldsecondcustomfield | <secondlinecustom> |
    When I log in as "admin"
    Then I should see smart menu "Quick links" item "<showntitle>" in location "Main, Menu, User, Bottom"

    Examples:
      | firstlinefield      | firstlinecustom | secondlinefield     | secondlinecustom | showntitle   |
      | Custom course field | testcf          | Course full name    |                  | Test course1 |
      | Course full name    |                 | Course short name   |                  | C1           |
      | Course full name    |                 | Custom course field | testcf           | Custom1      |

  Scenario: Smartmenus: Menu items: Presentation - Display the different fields as smart menu item second line (No second line case)
    Given the following "theme_boost_union > smart menu item" exists:
      | menu                    | Quick links          |
      | title                   | Available courses    |
      | itemtype                | Dynamic courses      |
      | category                | 0                    |
      # We just set the first line to avoid false positives with the second line values.
      | displayfield            | Custom course field  |
      | displayfieldcustomfield | testcf               |
      | displayfieldsecond      | -- No second line -- |
    When I log in as "admin"
    Then I should not see smart menu "Quick links" item "Test course1" in location "Main, Menu, User, Bottom"
    And I should not see smart menu "Quick links" item "C1" in location "Main, Menu, User, Bottom"
    And ".boost-union-smartmenu-secondline" "css_element" should not exist

  Scenario Outline: Smartmenus: Menu items: Presentation - Display the smart menu item course full name with a word count
    Given the following "theme_boost_union > smart menu item" exists:
      | menu                          | Quick links              |
      | title                         | Available courses        |
      | itemtype                      | Dynamic courses          |
      | category                      | 0                        |
      | displayfield                  | <firstlinefield>         |
      | displayfieldcustomfield       | <firstlinecustom>        |
      | textcount                     | <numberofwords>          |
      | displayfieldsecond            | <secondlinefield>        |
      | displayfieldsecondcustomfield | <secondlinecustom>       |
      | textcountsecond               | <secondlinewords>        |
    When I log in as "admin"
    Then I should see smart menu "Quick links" item "<showntitle>" in location "Main, Menu, User, Bottom"
    And I should not see smart menu "Quick links" item "<notshowntitle>" in location "Main, Menu, User, Bottom"

    Examples:
      | firstlinefield                         | firstlinecustom | numberofwords | secondlinefield      | secondlinecustom | secondlinewords | showntitle                                           | notshowntitle          |
      # First line - no word count: full course name is shown unchanged.
      | Course full name                       |                 |               | -- No second line -- |                  |                 | Test course word count                               | Test course..          |
      # First line - Course short name: short name is never truncated, even if textcount is set.
      | Course short name                      |                 | 2             | -- No second line -- |                  |                 | C3 has a very long short name                        | C3 has..               |
      # First line - Custom course field: custom field is never truncated, even if textcount is set.
      | Custom course field                    | testcf          | 2             | -- No second line -- |                  |                 | Custom3 has a very long custom field                 | Custom3 has..          |
      # First line - Course full name, word count = 2: full name is truncated.
      | Course full name                       |                 | 2             | -- No second line -- |                  |                 | Test course..                                        | Test course word count |
      # First line - combined fields: only the full name part is truncated, the other part is kept intact.
      | Course full name (Course short name)   |                 | 2             | -- No second line -- |                  |                 | Test course.. (C3 has a very long short name)        | Test course word count |
      | Course short name (Course full name)   |                 | 2             | -- No second line -- |                  |                 | C3 has a very long short name (Test course..)        | Test course word count |
      | Course full name (Custom course field) | testcf          | 2             | -- No second line -- |                  |                 | Test course.. (Custom3 has a very long custom field) | Test course word count |
      # Second line - Course full name, no word count: full course name is shown unchanged in second line.
      | Course short name                      |                 |               | Course full name     |                  |                 | Test course word count                               | Test course..          |
      # Second line - Course short name: short name is never truncated, even if textcountsecond is set.
      | Course full name                       |                 | 2             | Course short name    |                  | 2               | C3 has a very long short name                        | C3 has..               |
      # Second line - Custom course field: custom field is never truncated, even if textcountsecond is set.
      | Course full name                       |                 | 2             | Custom course field  | testcf           | 2               | Custom3 has a very long custom field                 | Custom3 has..          |
      # Second line - Course full name, word count = 2: full name in second line is truncated.
      | Course short name                      |                 |               | Course full name     |                  | 2               | Test course..                                        | Test course word count |

  @javascript
  Scenario: Smartmenus: Menu items: Presentation - Display the menu item title in different types
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links     |
      | title    | External links  |
      | itemtype | Heading         |
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links        |
      | title    | Resources          |
      | itemtype | Static             |
      | url      | https://moodle.org |
    When I log in as "admin"
    And I should see smart menu "Quick links" item "External links" in location "Main, Menu, User, Bottom"
    # Menu items in the main menu.
    And I click on "Quick links" "link" in the ".primary-navigation" "css_element"
    Then I should see "External links" in the ".primary-navigation .menu-item-heading" "css_element"
    And I should see "Resources" in the ".primary-navigation .menu-item-static" "css_element"
    And the "href" attribute of ".primary-navigation .menu-item-heading" "css_element" should contain "#"
    And the "href" attribute of ".primary-navigation .menu-item-static" "css_element" should contain "https://moodle.org"
    # Menu items in the menu bar.
    And I click on "Quick links" "link" in the ".boost-union-menubar" "css_element"
    Then I should see "External links" in the ".boost-union-menubar .menu-item-heading" "css_element"
    And I should see "Resources" in the ".boost-union-menubar .menu-item-static" "css_element"
    And the "href" attribute of ".boost-union-menubar .menu-item-heading" "css_element" should contain "#"
    And the "href" attribute of ".boost-union-menubar .menu-item-static" "css_element" should contain "https://moodle.org"
    # Menu items in user menu.
    And I click on "#user-menu-toggle" "css_element"
    And I click on "Quick links" "link" in the "#usermenu-carousel" "css_element"
    Then I should see "External links" in the "#usermenu-carousel .menu-item-heading" "css_element"
    And I should see "Resources" in the "#usermenu-carousel .menu-item-static" "css_element"
    And the "href" attribute of "//div[contains(@id, 'usermenu-carousel')]//div[contains(@class, 'carousel-item')]//a[contains(@class, 'menu-item-heading')]" "xpath_element" should contain "#"
    And the "href" attribute of "//div[contains(@id, 'usermenu-carousel')]//div[contains(@class, 'carousel-item')]//a[contains(@class, 'menu-item-static')]" "xpath_element" should contain "https://moodle.org"
    # Menu items in bottom menu.
    And I change viewport size to "740x900"
    And I click on "Quick links" "link" in the ".bottom-navigation" "css_element"
    Then I should see "External links" in the ".bottom-navigation .menu-item-heading" "css_element"
    And I should see "Resources" in the ".bottom-navigation .menu-item-static" "css_element"
    And the "href" attribute of "//div[@class='bottom-navigation']//a[contains(@class, 'menu-item-heading')]" "xpath_element" should contain "#"
    And the "href" attribute of "//div[@class='bottom-navigation']//a[contains(@class, 'menu-item-static')]" "xpath_element" should contain "https://moodle.org"

  Scenario: Smartmenus: Menu items: Presentation - Display the menu items in different order
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links         |
      | title    | Demo item 01        |
      | itemtype | Static              |
      | url      | https://example.com |
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links         |
      | title    | Demo item 02        |
      | itemtype | Static              |
      | url      | https://example.com |
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links         |
      | title    | Demo item 03        |
      | itemtype | Static              |
      | url      | https://example.com |
    When I log in as "admin"
    And I click on "Quick links" "link" in the ".primary-navigation" "css_element"
    And "Demo item 02" "text" should appear after "Demo item 01" "text"
    And "Demo item 03" "text" should appear after "Demo item 02" "text"
    And the following "theme_boost_union > smart menu item" exists:
      | menu      | Quick links         |
      | title     | Demo item 04        |
      | itemtype  | Static              |
      | url       | https://example.com |
      | sortorder | 6                   |
    And the following "theme_boost_union > smart menu item" exists:
      | menu      | Quick links         |
      | title     | Demo item 05        |
      | itemtype  | Static              |
      | url       | https://example.com |
      | sortorder | 4                   |
    And all Boost Union MUC caches are purged
    And I reload the page
    And "Demo item 04" "text" should appear after "Demo item 03" "text"
    And "Demo item 04" "text" should appear after "Demo item 05" "text"

  # The following "Smartmenus: Menu items: Presentation - Display the menu items in different viewports" scenarios look like they
  # could be combined into a single scenario outline, but they are not because with the scenario outline approach, the test
  # would attempt to open menus that were hidden due to having no items.

  @javascript
  Scenario: Smartmenus: Menu items: Presentation - Display the menu items in different viewports - hide the menu items on mobile devices
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links        |
      | title    | Resources          |
      | itemtype | Static             |
      | url      | https://moodle.org |
      | desktop  | 0                  |
      | tablet   | 0                  |
      | mobile   | 1                  |
    When I log in as "admin"
    Then I should see smart menu "Quick links" item "Resources" in location "Menu, Main, User"
    And I change viewport size to "tablet"
    Then I should see smart menu "Quick links" item "Resources" in location "User, Menu"
    And I click on "More" "link" in the ".primary-navigation" "css_element"
    Then I should see smart menu "Quick links" item "Resources" in location "Main"
    And I change viewport size to "mobile"
    Then "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Menu bar smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > User menu smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Bottom bar smart menu" should not be visible

  @javascript
  Scenario: Smartmenus: Menu items: Presentation - Display the menu items in different viewports - hide the menu items on tablet and mobile devices
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links        |
      | title    | Resources          |
      | itemtype | Static             |
      | url      | https://moodle.org |
      | desktop  | 0                  |
      | tablet   | 1                  |
      | mobile   | 1                  |
    When I log in as "admin"
    Then I should see smart menu "Quick links" item "Resources" in location "Menu, Main, User"
    And I change viewport size to "tablet"
    Then "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Menu bar smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > User menu smart menu" should not be visible
    And I click on "More" "link" in the ".primary-navigation" "css_element"
    Then "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Main menu smart menu" should not be visible
    And I change viewport size to "mobile"
    Then "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Menu bar smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > User menu smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Bottom bar smart menu" should not be visible

  @javascript
  Scenario: Smartmenus: Menu items: Presentation - Display the menu items in different viewports - hide the menu items on desktop devices
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links        |
      | title    | Resources          |
      | itemtype | Static             |
      | url      | https://moodle.org |
      | desktop  | 1                  |
      | tablet   | 0                  |
      | mobile   | 0                  |
    When I log in as "admin"
    Then "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Main menu smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Menu bar smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > User menu smart menu" should not be visible
    And I change viewport size to "tablet"
    Then I should see smart menu "Quick links" item "Resources" in location "User, Menu"
    And I click on "More" "link" in the ".primary-navigation" "css_element"
    Then I should see smart menu "Quick links" item "Resources" in location "Main"
    And I change viewport size to "mobile"
    Then I should see smart menu "Quick links" item "Resources" in location "Menu, User"
    And I should see smart menu "Quick links" item "Resources" in location "Bottom"

  @javascript
  Scenario: Smartmenus: Menu items: Presentation - Display the menu items in different viewports - hide the menu items on desktop and mobile devices
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links        |
      | title    | Resources          |
      | itemtype | Static             |
      | url      | https://moodle.org |
      | desktop  | 1                  |
      | tablet   | 0                  |
      | mobile   | 1                  |
    When I log in as "admin"
    Then "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Main menu smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Menu bar smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > User menu smart menu" should not be visible
    And I change viewport size to "tablet"
    Then I should see smart menu "Quick links" item "Resources" in location "User, Menu"
    And I click on "More" "link" in the ".primary-navigation" "css_element"
    Then I should see smart menu "Quick links" item "Resources" in location "Main"
    And I change viewport size to "mobile"
    Then "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Menu bar smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > User menu smart menu" should not be visible
    And "Resources" "theme_boost_union > Smart menu item" in the "Quick links" "theme_boost_union > Bottom bar smart menu" should not be visible

  @javascript
  Scenario: Smartmenus: Menu items: Presentation - Select an existing icon from the icon autocomplete list
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links |
      | title    | Resources   |
      | itemtype | Heading     |
    When I log in as "admin"
    And I navigate to smart menu "Quick links" items
    And I should see "Resources" in the "smartmenus_items" "table"
    And I click on ".action-edit" "css_element" in the "Resources" "table_row"
    And I click on ".form-autocomplete-downarrow" "css_element" in the "#fitem_id_menuicon" "css_element"
    And I set the field "Icon" to "fa-folder"
    And I should see "path_folder" in the "#fitem_id_menuicon .form-autocomplete-selection" "css_element"

  # Unfortunately, this can't be tested with Behat as Behat would throw an
  # 'Unable to find 'nonexistingicon' in the list of options, and unable to create a new option (InvalidArgumentException)'
  # exception when trying to select an unexisting icon.
  # Scenario: Smartmenus: Menu items: Presentation - Select an unexisting icon from the icon autocomplete list

  @javascript
  Scenario Outline: Smartmenus: Menu items: Presentation - Display the menu items title with icon
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links         |
      | title    | Resources           |
      | itemtype | Heading             |
      | display  | <presentationtitle> |
    When I log in as "admin"
    And I navigate to smart menu "Quick links" items
    And I should see "Resources" in the "smartmenus_items" "table"
    And I click on ".action-edit" "css_element" in the "Resources" "table_row"
    And I click on ".form-autocomplete-downarrow" "css_element" in the "#fitem_id_menuicon" "css_element"
    And I should see "<iconname>" in the "#fitem_id_menuicon .form-autocomplete-suggestions [data-value='<iconvalue>'] small" "css_element"
    And I should see "<iconbadge>" in the "#fitem_id_menuicon .form-autocomplete-suggestions [data-value='<iconvalue>'] span.badge" "css_element"
    And the "class" attribute of "#fitem_id_menuicon .form-autocomplete-suggestions [data-value='<iconvalue>'] i.fa" "css_element" should contain "<faicon>"
    And I click on "<iconname>" item in the autocomplete list
    And I press the escape key
    And I click on "Save changes" "button"
    And I click on ".action-edit" "css_element" in the "Resources" "table_row"
    # Open the menu item entry again to check the style of the auto-selected value.
    And I should see "<iconname>" in the "#fitem_id_menuicon .form-autocomplete-selection [data-value='<iconvalue>'] small" "css_element"
    And I should see "<iconbadge>" in the "#fitem_id_menuicon .form-autocomplete-selection [data-value='<iconvalue>'] span.badge" "css_element"
    And the "class" attribute of "#fitem_id_menuicon .form-autocomplete-selection [data-value='<iconvalue>'] i.fa" "css_element" should contain "<faicon>"
    And I click on "Save changes" "button"
    # We cannot use the "I should see smart menu item step" here because it checks only for the text, not for the icon.
    # Instead, we open the menu and check for the icon presence manually.
    And I click on "Quick links" "link" in the ".primary-navigation" "css_element"
    Then ".<faicon>" "css_element" should exist in the ".primary-navigation .dropdown-item.menu-item-heading" "css_element"
    And ".<faicon>" "css_element" should exist in the ".boost-union-menubar .dropdown-item" "css_element"
    And ".<faicon>" "css_element" should exist in the "#usermenu-carousel .carousel-item.submenu .dropdown-item" "css_element"
    And I <desktoptextcheck> see "Resources" in the ".primary-navigation .dropdown-item.menu-item-heading" "css_element"
    And I change viewport size to "mobile"
    And I click on "More" "button" in the ".bottom-navigation" "css_element"
    And I click on "Quick links" "link" in the "#theme_boost-drawers-primary" "css_element"
    Then ".<faicon>" "css_element" should exist in the ".primary-navigation .dropdown-item.menu-item-heading" "css_element"
    And ".<faicon>" "css_element" should exist in the ".boost-union-menubar .dropdown-item" "css_element"
    And ".<faicon>" "css_element" should exist in the "#usermenu-carousel .carousel-item.submenu .dropdown-item" "css_element"
    And I <mobiletextcheck> see "Resources" in the "#theme_boost-drawers-primary" "css_element"

    Examples:
      | presentationtitle                                      | iconname          | iconvalue                        | iconbadge         | faicon         | desktoptextcheck | mobiletextcheck |
      | Show text and icon as title                            | fa-circle-info    | theme_boost_union:fa-circle-info | FontAwesome Solid | fa-circle-info | should           | should          |
      | Show text and icon as title                            | core:i/circleinfo | core:i/circleinfo                | Moodle core       | fa-circle-info | should           | should          |
      | Hide title text and show only icon (on all devices)    | fa-circle-info    | theme_boost_union:fa-circle-info | FontAwesome Solid | fa-circle-info | should not       | should not      |
      | Hide title text and show only icon (on all devices)    | core:i/circleinfo | core:i/circleinfo                | Moodle core       | fa-circle-info | should not       | should not      |
      | Hide title text and show only icon (on mobile devices) | fa-circle-info    | theme_boost_union:fa-circle-info | FontAwesome Solid | fa-circle-info | should           | should not      |
      | Hide title text and show only icon (on mobile devices) | core:i/circleinfo | core:i/circleinfo                | Moodle core       | fa-circle-info | should           | should not      |

  @javascript
  Scenario Outline: Smartmenus: Menu items: Presentation - Display the tooltip on hover over the menu items
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links        |
      | title    | Resources          |
      | itemtype | Static             |
      | url      | https://moodle.org |
      | tooltip  | <tooltip>          |
    When I log in as "admin"
    And I click on "Quick links" "link" in the ".primary-navigation" "css_element"
    And I hover over the "Resources" "text" in the ".primary-navigation" "css_element"
    Then "body > .tooltip" "css_element" <shouldornot> exist
    And I <shouldornot> see "External links"

    Examples:
      | tooltip        | shouldornot |
      | External links | should      |
      |                | should not  |

  @javascript
  Scenario: Smartmenus: Menu items: Presentation - Display the card type menu items title with different position and color
    When I log in as "admin"
    And I navigate to smart menus
    And I click on ".action-edit" "css_element" in the "Quick links" "table_row"
    And I set the field "Presentation type" to "Card"
    And I click on "Save and return" "button"
    And the following "theme_boost_union > smart menu item" exists:
      | menu         | Quick links          |
      | title        | Resources below      |
      | itemtype     | Static               |
      | url          | https://moodle.org/1 |
      | textposition | Below image          |
      | textcolor    | #FFFEFF              |
    And the following "theme_boost_union > smart menu item" exists:
      | menu         | Quick links          |
      | title        | Resources top        |
      | itemtype     | Static               |
      | url          | https://moodle.org/2 |
      | textposition | Top overlay          |
      | textcolor    | #230017              |
    And the following "theme_boost_union > smart menu item" exists:
      | menu         | Quick links          |
      | title        | Resources bottom     |
      | itemtype     | Static               |
      | url          | https://moodle.org/3 |
      | textposition | Bottom overlay       |
    And all Boost Union MUC caches are purged
    And I am on site homepage
    And I click on "Quick links" "link" in the ".primary-navigation" "css_element"
    Then I should see "Resources below" in the ".primary-navigation .dropdown-menu.show" "css_element"
    And "//div[contains(@class, 'card-text-below')]//a[contains(., 'Resources below')]" "xpath_element" should exist
    And DOM element ".dropdown-menu.show .card-text-below .content-block a.dropdown-item" should have computed style "color" "rgb(255, 254, 255)"
    And I should see "Resources top" in the ".primary-navigation .dropdown-menu.show" "css_element"
    And "//div[contains(@class, 'card-text-overlay-top')]//a[contains(., 'Resources top')]" "xpath_element" should exist
    And DOM element ".dropdown-menu.show .card-text-overlay-top .content-block a.dropdown-item" should have computed style "color" "rgb(35, 0, 23)"
    And DOM element ".dropdown-menu.show .card-text-overlay-top .content-block" should have computed style "position" "absolute"
    And I should see "Resources bottom" in the ".primary-navigation .dropdown-menu.show" "css_element"
    And "//div[contains(@class, 'card-text-overlay-bottom')]//a[contains(., 'Resources bottom')]" "xpath_element" should exist
    And DOM element ".dropdown-menu.show .card-text-overlay-bottom .content-block" should have computed style "position" "absolute"
    And DOM element ".dropdown-menu.show .card-text-overlay-bottom .content-block" should have computed style "align-items" "flex-end"

  @javascript @_file_upload
  Scenario: Smartmenus: Menu items: Presentation - Display the card type menu item with background image and colors
    When I log in as "admin"
    And I navigate to smart menus
    And I click on ".action-edit" "css_element" in the "Quick links" "table_row"
    And I set the field "Presentation type" to "Card"
    And I click on "Save and return" "button"
    And the following "theme_boost_union > smart menu item" exists:
      | menu            | Quick links         |
      | title           | Resources           |
      | itemtype        | Static              |
      | url             | https://example.com |
      | backgroundcolor | #031FC3             |
    And all Boost Union MUC caches are purged
    And I am on site homepage
    And I click on "Quick links" "link" in the ".primary-navigation" "css_element"
    Then DOM element ".dropdown-menu .menu-item-static .content-block" should have computed style "background-color" "rgb(3, 31, 195)"
    And I click on "Quick links" "link" in the ".boost-union-menubar" "css_element"
    And DOM element ".boost-union-menubar .dropdown-menu.show .content-block" should have computed style "background-color" "rgb(3, 31, 195)"
    And I click on "Quick links" "link" in the ".boost-union-menubar" "css_element"
    And I navigate to smart menu "Quick links" items
    And I click on ".action-edit" "css_element" in the "Resources" "table_row"
    And I expand all fieldsets
    And I upload "theme/boost_union/tests/fixtures/backimg.png" file to "Card image" filemanager
    And I click on "Save changes" "button"
    And all Boost Union MUC caches are purged
    And I am on site homepage
    And I click on "Quick links" "link" in the ".primary-navigation" "css_element"
    Then the image at "//div[contains(@class, 'primary-navigation')]//img[contains(@src, 'pluginfile.php') and contains(@src, '/theme_boost_union/smartmenus_itemimage/')]" "xpath_element" should be identical to "theme/boost_union/tests/fixtures/backimg.png"

  Scenario: Smartmenu: Menu items: Presentation - Add a smart menu item with multilang tags
    Given the following "language packs" exist:
      | language |
      | de       |
    And the "multilang" filter is "on"
    And the "multilang" filter applies to "content and headings"
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links                                                                                                 |
      | title    | <span lang="en" class="multilang">Lorem ipsum</span><span lang="de" class="multilang">Dolor sit amet</span> |
      | itemtype | Static                                                                                                      |
      | url      | https://moodle.org/foo                                                                                      |
    When I log in as "admin"
    And I follow "Preferences" in the user menu
    And I click on "Preferred language" "link"
    And I set the field "Preferred language" to "English ‎(en)‎"
    And I press "Save changes"
    And I am on site homepage
    Then I should see smart menu "Quick links" item "Lorem ipsum" in location "Main, Menu, User, Bottom"
    And I should not see smart menu "Quick links" item "Dolor sit amet" in location "Main, Menu, User, Bottom"
    And I follow "Preferences" in the user menu
    And I click on "Preferred language" "link"
    And I set the field "Preferred language" to "Deutsch ‎(de)‎"
    And I press "Save changes"
    And I am on site homepage
    Then I should see smart menu "Quick links" item "Dolor sit amet" in location "Main, Menu, User, Bottom"
    And I should not see smart menu "Quick links" item "Lorem ipsum" in location "Main, Menu, User, Bottom"

  Scenario: Smartmenus: Menu items: Presentation - Hide empty menus (in submenu mode)
    Given the following "theme_boost_union > smart menu" exists:
      | title    | Links                                            |
      | location | Main navigation, Menu bar, User menu, Bottom bar |
      | mode     | Submenu                                          |
    When I log in as "admin"
    And "Links" "theme_boost_union > Main menu smart menu" should not exist
    And "Links" "theme_boost_union > Menu bar smart menu" should not exist
    And "Links" "theme_boost_union > User menu smart menu" should not exist
    And "Links" "theme_boost_union > Bottom bar smart menu" should not exist
    And "Smartmenu Resource" "theme_boost_union > Main menu smart menu item" should not exist
    And "Smartmenu Resource" "theme_boost_union > Menu bar smart menu item" should not exist
    And "Smartmenu Resource" "theme_boost_union > User menu smart menu item" should not exist
    And "Smartmenu Resource" "theme_boost_union > Bottom bar smart menu item" should not exist
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | Links              |
      | title    | Smartmenu Resource |
      | itemtype | Static             |
      | url      | http://moodle.org  |
    And all Boost Union MUC caches are purged
    And I am on site homepage
    Then "Links" "theme_boost_union > Main menu smart menu" should exist
    And "Links" "theme_boost_union > Menu bar smart menu" should exist
    And "Links" "theme_boost_union > User menu smart menu" should exist
    And "Links" "theme_boost_union > Bottom bar smart menu" should exist

  Scenario: Smartmenus: Menu items: Presentation - Hide empty menus (in inline mode)
    Given the following "theme_boost_union > smart menu" exists:
      | title    | Links                                            |
      | location | Main navigation, Menu bar, User menu, Bottom bar |
      | mode     | Inline                                           |
    When I log in as "admin"
    And "Links" "theme_boost_union > Main menu smart menu" should not exist
    And "Links" "theme_boost_union > Menu bar smart menu" should not exist
    And "Links" "theme_boost_union > User menu smart menu" should not exist
    And "Links" "theme_boost_union > Bottom bar smart menu" should not exist
    And "Smartmenu Resource" "theme_boost_union > Main menu smart menu item" should not exist
    And "Smartmenu Resource" "theme_boost_union > Menu bar smart menu item" should not exist
    And "Smartmenu Resource" "theme_boost_union > User menu smart menu item" should not exist
    And "Smartmenu Resource" "theme_boost_union > Bottom bar smart menu item" should not exist
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | Links              |
      | title    | Smartmenu Resource |
      | itemtype | Static             |
      | url      | http://moodle.org  |
    And all Boost Union MUC caches are purged
    And I am on site homepage
    Then "Smartmenu Resource" "theme_boost_union > Main menu smart menu item" should exist
    And "Smartmenu Resource" "theme_boost_union > Menu bar smart menu item" should exist
    And "Smartmenu Resource" "theme_boost_union > User menu smart menu item" should exist
    And "Smartmenu Resource" "theme_boost_union > Bottom bar smart menu item" should exist

  Scenario Outline: Smartmenus: Menu items: Presentation - Image alt text for the dynamic menu items
    Given the following "theme_boost_union > smart menu" exists:
      | title    | Courses                                          |
      | location | Main navigation, Menu bar, User menu, Bottom bar |
      | type     | Card                                             |
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | Courses           |
      | title    | Available courses |
      | itemtype | Dynamic courses   |
      | category | 0                 |
      | itemmode | Inline            |
      | imagealt | <setting>         |
    When I log in as "admin"
    Then the "alt" attribute of "//div[contains(@class, 'primary-navigation')]//li[contains(@class, 'boost-union-smartmenu')]//a[contains(normalize-space(.), 'Test course1')]//ancestor-or-self::div[@class='content-block']/parent::div//div[@class='img-block']//img" "xpath_element" should contain "<testcourse1result>"
    And the "alt" attribute of "//div[contains(@class, 'primary-navigation')]//li[contains(@class, 'boost-union-smartmenu')]//a[contains(normalize-space(.), 'Test course2')]//ancestor-or-self::div[@class='content-block']/parent::div//div[@class='img-block']//img" "xpath_element" should contain "<testcourse2result>"
    And the "alt" attribute of "//div[contains(@class, 'primary-navigation')]//li[contains(@class, 'boost-union-smartmenu')]//a[contains(normalize-space(.), 'Test course word count')]//ancestor-or-self::div[@class='content-block']/parent::div//div[@class='img-block']//img" "xpath_element" should contain "<testcourse3result>"

    Examples:
      | setting                     | testcourse1result            | testcourse2result            | testcourse3result                      |
      | Image of course             | Image of course              | Image of course              | Image of course                        |
      | Image of course {menutitle} | Image of course Test course1 | Image of course Test course2 | Image of course Test course word count |
      |                             | Test course1                 | Test course2                 | Test course word count                 |

  Scenario Outline: Smartmenus: Menu items: Presentation - Image alt text for the static menu items
    Given the following "theme_boost_union > smart menu" exists:
      | title    | Links                                            |
      | location | Main navigation, Menu bar, User menu, Bottom bar |
      | type     | Card                                             |
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | Links             |
      | title    | Moodle org        |
      | itemtype | Static            |
      | url      | http://moodle.org |
      | imagealt | <link1setting>    |
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | Links                       |
      | title    | Moodle Plugins              |
      | itemtype | Static                      |
      | url      | https://moodle.org/plugins/ |
      | imagealt | <link2setting>              |
    When I log in as "admin"
    Then the "alt" attribute of "//div[contains(@class, 'primary-navigation')]//li[contains(@class, 'boost-union-smartmenu')]//a[contains(normalize-space(.), 'Moodle org')]//ancestor-or-self::div[@class='content-block']/parent::div//div[@class='img-block']//img" "xpath_element" should contain "<link1result>"
    And the "alt" attribute of "//div[contains(@class, 'primary-navigation')]//li[contains(@class, 'boost-union-smartmenu')]//a[contains(normalize-space(.), 'Moodle Plugins')]//ancestor-or-self::div[@class='content-block']/parent::div//div[@class='img-block']//img" "xpath_element" should contain "<link2result>"

    Examples:
      | link1setting                  | link2setting                      | link1result                   | link2result                       |
      | Image of moodle official site | Image of moodle plugins directory | Image of moodle official site | Image of moodle plugins directory |
      | Image of {menutitle}          | Image of {menutitle}              | Image of Moodle org           | Image of Moodle Plugins           |
      |                               |                                   | Moodle org                    | Moodle Plugins                    |

  @javascript
  Scenario: Smartmenus: Menu items: Presentation - Make full submenu header clickable
    Given the following "theme_boost_union > smart menu item" exists:
      | menu     | Quick links       |
      | title    | Available courses |
      | itemtype | Dynamic courses   |
      | category | 0                 |
      | itemmode | Submenu           |
    When I log in as "admin"
    And I click on "Quick links" "link" in the ".primary-navigation" "css_element"
    And I click on "Available courses" "link" in the ".primary-navigation" "css_element"
    Then I should see "Test course1" in the ".primary-navigation" "css_element"
    And I should see "Test course2" in the ".primary-navigation" "css_element"
    And I should see "Available courses" in the ".primary-navigation .header .carousel-navigation-link" "css_element"
    # Primary navigation.
    And I click on ".carousel-item.active .header" "css_element" in the ".primary-navigation" "css_element"
    Then I should see "Available courses" in the ".primary-navigation .carousel-item" "css_element"
    And I should not see "Available courses" in the ".primary-navigation .header .carousel-navigation-link" "css_element"
    And I should not see "Test course1" in the ".primary-navigation" "css_element"
    # User menu (where the header becomes fully clickable as soon as a smart menu is added).
    And I click on "#user-menu-toggle" "css_element"
    And I click on "Quick links" "link" in the "#usermenu-carousel" "css_element"
    And I click on "Available courses" "link" in the "#usermenu-carousel" "css_element"
    Then I should see "Test course1" in the "#usermenu-carousel" "css_element"
    And I should see "Test course2" in the "#usermenu-carousel" "css_element"
    And I should see "Available courses" in the "#usermenu-carousel .carousel-item.active .header .carousel-navigation-link" "css_element"
    And I click on ".carousel-item.active .header" "css_element" in the "#usermenu-carousel" "css_element"
    Then I should see "Available courses" in the "#usermenu-carousel .carousel-item.active" "css_element"
    And I should not see "Available courses" in the "#usermenu-carousel .carousel-item.active .header .carousel-navigation-link" "css_element"
    And I should not see "Test course1" in the "#usermenu-carousel" "css_element"

  @javascript
  Scenario: Smartmenus: Menu items: Presentation - Opening a smart menu submenu should not scroll to top of the page
    Given the following "theme_boost_union > smart menu" exists:
      | title    | All courses     |
      | location | Main navigation |
      | mode     | Submenu         |
    And the following "theme_boost_union > smart menu item" exists:
      | menu     | All courses     |
      | title    | Category 1      |
      | itemtype | Dynamic courses |
      | itemmode | Submenu         |
    When I log in as "admin"
    And I change the viewport size to "medium"
    And I am on "Test course1" course homepage
    And I make the navbar fixed
    Then I scroll page to DOM element with ID "page-footer"
    And I click on "All courses" "link" in the ".primary-navigation" "css_element"
    And I click on "Category 1" "link" in the ".primary-navigation" "css_element"
    Then page top is not at the top of the viewport
